from rest_framework import serializers

from polls.models import Post, Poll


class PostSerializer(serializers.ModelSerializer):
    poll_count = serializers.IntegerField(read_only=True)
    score_average = serializers.IntegerField(read_only=True)

    class Meta:
        model = Post
        fields = ('title', 'poll_count', 'score_average', )


class PollSerializer(serializers.ModelSerializer):

    class Meta:
        model = Poll
        fields = ('post', 'score')

    def validate(self, data):
        score = data['score']
        if not (-1 < score < 6):
            raise serializers.ValidationError('Invalid score ...!!!')
        return data

    def create(self, validated_data):
        request = self.context.get('request', None)
        user = request.user
        return Poll.objects.update_or_create(post=validated_data.get('post'), user=user,
                                             defaults={'score': validated_data.get('score')})
